<?php

class I95Dev_SalesPerson_Block_Adminhtml_Customer_Edit_Tabs
extends Mage_Adminhtml_Block_Customer_Edit_Tabs
{

    /**
     * Setting the text  on custom tab
     */
    public function __construct()
    {
        parent::__construct(); 
    }

    /**
     * @description Adding Quotes tab on left menu
     * @return type 
     */
    protected function _beforeToHtml()
    {
      
        //parent::_beforeToHtml();       
        $this->addTab('salesPerson', array(
            'label' => Mage::helper('I95Dev_SalesPerson')->__('Sales Person'),
            'content' => $this->getLayout()
                ->createBlock('salesPerson/adminhtml_customer_edit_tab_salesPerson')
                ->initForm()->toHtml(),
        )); 

        return  parent::_beforeToHtml();
    }

}
