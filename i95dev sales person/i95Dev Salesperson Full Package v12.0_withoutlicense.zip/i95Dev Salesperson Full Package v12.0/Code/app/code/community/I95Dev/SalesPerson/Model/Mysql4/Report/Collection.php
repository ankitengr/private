<?php

class I95Dev_SalesPerson_Model_Mysql4_Report_Collection 
extends Mage_Core_Model_Mysql4_Collection_Abstract
{

    /**
     * Initialize the resource model collection
     */
    public function _construct()
    {
        parent::_construct();
        $this->_init('salesPerson/salesPerson');
    }
    
    public function getReportFull($from, $to)
   {
       return $this->_model->getReportFull($this->timeShift($from), $this->timeShift($to));
   }
 
   public function timeShift($datetime)
   {
       return Mage::app()->getLocale()->utcDate(null, $datetime, true, Varien_Date::DATETIME_INTERNAL_FORMAT)->toString(Varien_Date::DATETIME_INTERNAL_FORMAT);
   }
    
    

}



?>
