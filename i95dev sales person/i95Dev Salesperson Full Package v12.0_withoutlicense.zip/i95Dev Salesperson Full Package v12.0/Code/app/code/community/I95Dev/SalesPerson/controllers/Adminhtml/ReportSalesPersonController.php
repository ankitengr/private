<?php

class I95Dev_SalesPerson_Adminhtml_ReportSalesPersonController 
extends Mage_Adminhtml_Controller_action
{
    
    public function _initAction()
    {
 
        $this->loadLayout()
        ->_addBreadcrumb(Mage::helper('I95Dev_SalesPerson')->__('Sales Person'),
                Mage::helper('I95Dev_SalesPerson')->__('Sales Person Reports'));
        return $this;
    }
   
    
    
    public function indexAction()
     {
         
         $this->_title(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person'))
             ->_title(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person Reports'));
          
        $this->_initAction();
        $this->_setActiveMenu('report/items');
        
        
        $this->_addContent(
               $this->getLayout()
                    ->createBlock('salesPerson/adminhtml_report_salesPerson')
                          );
        $this->renderLayout();
     }
     
     
     public function salesPersonOrdersAction()
     {
          
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person'))
             ->_title(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person Reports'));
          
             
        $this->_initAction();
        $this->_setActiveMenu('report/items');
        
        
        $this->_addContent(
               $this->getLayout()
                    ->createBlock('salesPerson/adminhtml_report_orders')
                          );
        $this->renderLayout();
     }
   
     
      public function exportOrdersCsvAction()
    {
        $fileName   = 'salesperson_users.csv';
        $grid = $this->getLayout()->createBlock('salesPerson/adminhtml_report_salesPerson');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }
    
     public function exportExcelAction()
    {
        $fileName = 'salesperson.xml';
        $grid = $this->getLayout()->createBlock('salesPerson/adminhtml_report_salesPerson');;
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }
 
} 
?>
