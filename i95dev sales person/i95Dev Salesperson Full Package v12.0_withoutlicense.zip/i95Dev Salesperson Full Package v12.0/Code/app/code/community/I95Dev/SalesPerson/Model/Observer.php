<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Model_Observer extends Varien_Event_Observer
{
    public function assignSalespersonOrder($observer)
    {
         $order = $observer->getEvent()->getOrder();

         $orderId = $order->getIncrementId();

         
        $customer_id = $observer->getEvent()->getOrder()->getCustomerId();
           
        $order = Mage::getModel('sales/order')->getCollection()
                ->addFieldToFilter('increment_id', $orderId)
                ->getFirstItem();
         
        $customerData = Mage::getModel('customer/customer')->load($customer_id); 
        $customerSalesPerson = $customerData->getErpSalespersonCode();
         
        
         
        $salesPersonObject = Mage::getModel('salesPerson/salesPerson_salesPerson')
                            ->load($customerSalesPerson,'username');
        
        $salesPersonCommsion = $salesPersonObject->getCommission();
        $salesPersonTotalCommision = $salesPersonObject->getTotalCommission();
        
        if($salesPersonTotalCommision == NULL)
        {
            $salesPersonTotalCommision =0;
        } 
        $data['salespersonid']=$salesPersonObject->getUsername(); 
        $_assCSR = Mage::getModel('sales/order')->load($orderId, 'increment_id');
                  
                 $orderGrandTotal = $_assCSR->getGrandTotal();
                  
                  $salesPersonTotalCommision = $salesPersonTotalCommision + $orderGrandTotal*$salesPersonCommsion/100;
                  $orderCommission = $orderGrandTotal*$salesPersonCommsion/100;
                  
                  $salesPersonObject->setData('total_commission',$salesPersonTotalCommision);
                  $salesPersonObject->save();
                  
                  $_assCSR->setData('erp_salesperson_code', $customerSalesPerson); 
                  $_assCSR->setData('salesperson_commission',$orderCommission);   
                  $_assCSR->save();   
    }

}
