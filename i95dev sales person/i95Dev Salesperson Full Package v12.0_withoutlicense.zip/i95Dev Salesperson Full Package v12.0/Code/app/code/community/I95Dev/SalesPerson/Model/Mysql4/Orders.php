<?php

class I95Dev_SalesPerson_Model_Mysql4_Orders
extends  Mage_Core_Model_Mysql4_Collection_Abstract
{

    /**
     * Initialize the resource model collection
     */
    public function _construct()
    {
       
         parent::_construct();
          $mainTable = 'orders1234'; // check the node in the config.xml
        $idFieldName = 'entity_id'; // whatever the column is named.
        
         $this->_init("salesPerson/salesPerson", "salesPerson_id");
      
    }
     

}
?>