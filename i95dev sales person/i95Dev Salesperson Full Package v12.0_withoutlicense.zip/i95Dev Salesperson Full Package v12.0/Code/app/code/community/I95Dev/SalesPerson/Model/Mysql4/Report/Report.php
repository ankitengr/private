<?php

class I95Dev_SalesPerson_Model_Mysql4_Report_Report
extends Mage_Core_Model_Mysql4_Collection_Abstract
{

    /**
     * Initialize the resource model collection
     */
    public function _construct()
    {
        parent::_construct();
        $this->_init('salesPerson/salesPerson');
    }
    
    public function setDateRange($frmdate, $todate)
    {
        $this->addOrders($frmdate,$todate);
        return $this;
    }
     public function setPageSize($frmdate, $todate)
    {       
        return $this;
    } 
    public function setStoreIds() 
    {
        return $this;
    }
    
    public function addOrders($frmdate,$todate)
    {  
        
       $collections = $this->addAttributeToSelect('*'); 
       return $collections;

    }
     

}
?>