<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_SalesPerson_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

    /**
     * Setting the Default ERP To Magento Events Grid form values
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('salesPersonGrid');
        $this->setDefaultSort('salesperson_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
    }

    /**
     * Preparing the ERP Salesperson collection
     * @return type 
     */
    protected function _prepareCollection()
    {
        $sales_order = Mage::getSingleton('core/resource')->getTableName('sales/order');
         
        $collection = Mage::getModel('salesPerson/salesPerson_salesPerson')->getCollection();
         
       /**$collection->getSelect()
              ->join(
                      array('sales_order'=>$sales_order),
                      'sales_order.erp_salesperson_code = main_table.username',
                      'sales_order.salesperson_commission'
                      );
        **/
         //$collection->getSelect()->columns(array('total' => 'sum(sales_order.salesperson_commission)'));
       // $collection->getCollection();
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    /**
     * Preparing the Grid columns for Salesperson
     * @return type 
     */
    protected function _prepareColumns()
    {
        $store = $this->_getStore();
        $this->addColumn('salesperson_id', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('ID'),
            'align' => 'right',
            'width' => '25px',
            'index' => 'salesPerson_id',
        ));

        $this->addColumn('username', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Sales Person User ID'),
            'align' => 'left',
            'index' => 'username',
            'width' => '140px',
        ));

        $this->addColumn('firstname', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('First Name'),
            'width' => '110px',
            'index' => 'firstname',
        ));
        $this->addColumn('lastname', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Last Name'),
            'width' => '110px',
            'index' => 'lastname',
        ));
        $this->addColumn('email', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Email'),
            'width' => '140px',
            'index' => 'email',
        ));
        $this->addColumn('status', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Is Active'),
            'width' => '100px',
            'align' => 'left',
            'type' => 'options',
            'options' => array('1' => Mage::Helper('I95Dev_SalesPerson')->__('Yes'), '0' => Mage::Helper('I95Dev_SalesPerson')->__('No')),
            'width' => '100px',
            'index' => 'status',
        ));
        $this->addColumn('commission', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Commission %'),
            'width' => '80px',
            'index' => 'commission',
        ));
        /**
        $this->addColumn('total', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Total Commission'),
            'width' => '80px',
            'index' => 'total',
            'type' => 'price',
            'currency_code' => $store->getBaseCurrency()->getCode(),
            'filter_index' => 'total',
        ));
        **/
        
         
        $this->addColumn('total_commission', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Total Commission'),
            'width' => '80px',
            'index' => 'total_commission',
            'type' => 'price',
            'currency_code' => $store->getBaseCurrency()->getCode(),
            'filter_index' => 'total_commission',
        )); 
        $this->addColumn('action', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Action'),
            'width' => '100',
            'type' => 'action',
            'getter' => 'getId',
            'actions' => array(
                array(
                    'caption' => Mage::Helper('I95Dev_SalesPerson')->__('Edit'),
                    'url' => array('base' => '*/*/edit'),
                    'field' => 'id'
                )
            ),
            'filter' => false,
            'sortable' => false,
            'index' => 'stores',
            'is_system' => true,
        ));

        $this->addExportType('*/*/exportCsv', Mage::helper('I95Dev_SalesPerson')->__('CSV')); 
			  $this->addExportType('*/*/exportExcel', Mage::helper('I95Dev_SalesPerson')->__('Excel'));

        return parent::_prepareColumns();
    }
    
    /*
     * Mass Action for Deleting Salesperson
     * 
     */
     protected function _prepareMassaction()
    {
        $this->setMassactionIdField('salesPerson_id');
        $this->getMassactionBlock()->setFormFieldName('salesPerson');
        $this->getMassactionBlock()->addItem('delete', array(
        'label'=> Mage::helper('tax')->__('Delete'),
        'url'  => $this->getUrl('*/*/massDelete', array('' => '')),        // public function massDeleteAction() in Mage_Adminhtml_Tax_RateController
        'confirm' => Mage::helper('tax')->__('Are you sure?')
        ));
        
        return $this;
        
    }
    
    

    /**
     * Geting the Each Row URL in Grid
     */
    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }

    /**
     * function for get store
     * @return type 
     */
    protected function _getStore()
    {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
    }

}