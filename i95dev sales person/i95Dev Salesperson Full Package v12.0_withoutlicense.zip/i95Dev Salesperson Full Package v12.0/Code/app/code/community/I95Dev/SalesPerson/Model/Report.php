<?php
 
class I95Dev_SalesPerson_Model_Report
extends Mage_Core_Model_Abstract  
{
    protected $_reportModel;

    
     protected function _construct()
    {
        parent::_construct();
        $this->_init('salesPerson/salesPerson');
    }  
}
    


?>
