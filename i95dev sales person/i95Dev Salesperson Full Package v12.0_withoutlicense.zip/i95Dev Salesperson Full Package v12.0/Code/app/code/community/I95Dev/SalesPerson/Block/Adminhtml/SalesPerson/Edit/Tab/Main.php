<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 * @category	     Sunfood
 * @package        Sunfood_Salesperson
 * @Description    admin user form 
 * @author         Javed
 * @copyright      Copyright (c) 2011 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */

/**
 * form for admin user creation and edition
 */
class I95Dev_SalesPerson_Block_Adminhtml_Salesperson_Edit_Tab_Main extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Function for prepare Form
     * @return type 
     */
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $userid = Mage::app()->getRequest()->getParam('id');
        $User = Mage::getModel('salesPerson/salesPerson_salesPerson')->load($userid, 'salesperson_id');
        $userData = $User->getData();
        $username_flag = false;
        $this->setForm($form);

        if (!empty($userData))
        {
            $streetaddress1 = $userData['address1'];
            $streetaddress2 = $userData['address2'];
            $streetaddress3 = $userData['address3'];
            $streetaddress4 = $userData['address4'];
            $city = $userData['city'];
            $zip = $userData['zip_code'];
            $country = $userData['country'];
            $phone2 = $userData['phone2'];
            $phone1 = $userData['phone1'];
            $phone3 = $userData['phone3'];
            $fax = $userData['fax'];
            $state = $userData['state'];
        }
        else
        {
            $streetaddress1 = '';
            $streetaddress2 = "";
            $streetaddress3 = "";
            $streetaddress4 = "";
            $city = "";
            $zip = "";
            $phone1 = '';
            $phone2 = "";
            $phone3 = "";
            $fax = "";
            $state = "";
            $country = "";
        }
        $fieldset = $form->addFieldset('base_fieldset', array('legend' => Mage::Helper('I95Dev_SalesPerson')->__('Sales Person Details')));
        $fieldset->addField('streetaddress1', 'text', array(
            'name' => 'streetaddress1',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Address'),
            'id' => 'streetaddress1',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('streetaddress1'),
            'value' => $streetaddress1,
        ));
        $fieldset->addField('streetaddress2', 'text', array(
            'name' => 'streetaddress2',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__(''),
            'id' => 'streetaddress2',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('streetaddress2'),
            'value' => $streetaddress2,
        ));
        $fieldset->addField('streetaddress3', 'text', array(
            'name' => 'streetaddress3',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__(''),
            'id' => 'streetaddress3',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('streetaddress3'),
            'value' => $streetaddress3,
        ));
        $fieldset->addField('city', 'text', array(
            'name' => 'city',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('City'),
            'id' => 'city',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('city'),
            'value' => $city,
        ));
        $countryName = Mage::getModel('directory/country')->load($country, 'iso2_code');

        $fieldset->addField('state', 'text', array(
            'name' => 'state',
            'label' => 'State',
            'values'    => Mage::getModel('adminhtml/system_config_source_allregion')->toOptionArray(),
            'value' => $state,
        ));
        $fieldset->addField('country', 'text', array(
            'name' => 'country',
            'label' => 'Country',
            'values'    => Mage::getModel('adminhtml/system_config_source_country')->toOptionArray(),
            'value' => $country,
        ));
        $fieldset->addField('zip_code', 'text', array(
            'name' => 'zip_code',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Zip Code'),
            'id' => 'zip_code',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('zip_code'),
            'value' => $zip,
        ));
        $fieldset->addField('phone1', 'text', array(
            'name' => 'phone1',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Phone 1'),
            'id' => 'phone1',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('phone1'),
            'value' => $phone1,
        ));
        $fieldset->addField('phone2', 'text', array(
            'name' => 'phone2',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Phone 2'),
            'id' => 'phone2',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('phone2'),
            'value' => $phone2,
        ));
        $fieldset->addField('phone3', 'text', array(
            'name' => 'phone3',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Phone 3'),
            'id' => 'phone3',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('phone3'),
            'value' => $phone3,
        ));
        $fieldset->addField('fax', 'text', array(
            'name' => 'fax',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Fax'),
            'id' => 'fax',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('fax'),
            'value' => $fax,
        ));

        if (Mage::getSingleton("adminhtml/session")->getSalespersonData())
        {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getSalespersonData());
            Mage::getSingleton("adminhtml/session")->setSalespersonData(null);
        }
        elseif (Mage::registry("salesperson_data"))
        {
            $form->setValues(Mage::registry("salesperson_data")->getData());
        }
        return parent::_prepareForm();
    }

}