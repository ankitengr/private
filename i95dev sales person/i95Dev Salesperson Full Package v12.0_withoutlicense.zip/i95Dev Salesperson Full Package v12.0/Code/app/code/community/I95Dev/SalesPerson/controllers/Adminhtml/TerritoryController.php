<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Territory controller for display territories grid
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */

class I95Dev_SalesPerson_Adminhtml_TerritoryController extends Mage_Adminhtml_Controller_action
{
    
    protected function _initAction()
    {
         
        $this->loadLayout()
                ->_setActiveMenu("salesPerson/territory")
                ->_addBreadcrumb(Mage::helper("adminhtml")
                  ->__("Territory  Manager"), Mage::helper("adminhtml")->__("Territory Manager"));
        return $this;
    }

    public function indexAction()
    {
         
        $this->_title(Mage::helper('I95Dev_SalesPerson')->__("Sales Person"));
        $this->_title(Mage::helper('I95Dev_SalesPerson')->__("Manage Territory"));
        $this->_initAction();
        $this->renderLayout();
    }
 
    
    /**
     * Function to edit action
     * Edit Action for Sales person
     */
    public function editAction()
    {   
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Territory")); 
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Edit Territory"));
        $_id = $this->getRequest()->getParam('id');
         
        $_territoryModel = Mage::getModel('salesPerson/territory')->load($_id);
           
        //print_r($_territoryModel->getTerritoryId()); die;  
        
        if ($_territoryModel->getTerritoryId() || $_id == 0)
        {
             $_data = Mage::getSingleton('adminhtml/session')->getFormData(true);
             $_data = $_territoryModel->getFormData(true);
            
            //print_r($_data); die;
            if (!empty($_data))
            {
                $_territoryModel->setData($_data);
            }
            
            //$_territoryModel->setData($_data);
            
            Mage::register('territory_data', $_territoryModel);
            
            $this->loadLayout(); 
            $this->_setActiveMenu("salesPerson/territory")
                ->_addBreadcrumb(Mage::helper("adminhtml")
                  ->__("Territory  Manager"), Mage::helper("adminhtml")->__("Territory Manager"));
             
            
            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);

            $this->_addContent($this->getLayout()->createBlock('salesPerson/adminhtml_territory_edit'))
                 ->_addLeft($this->getLayout()->createBlock('salesPerson/adminhtml_territory_edit_tabs'));
            $this->renderLayout();
        }
         else
        {
            Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Item does not exist'));
            $this->_redirect('*/*/');
        }
        
    }
  
     
     
    /**
     * Function for new action
     * This fucntion will create a new Territory 
     */ 
    public function newAction()  
    {   
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Territory"));
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Territory"));
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("New Territory"));
        
        //$this->_forward('edit'); 
          $this->_redirect('salesPerson/adminhtml_territory/edit');
        
    }
    
    public function saveAction()
    {  
        $_data = $this->getRequest()->getPost();
        $timeNow = date('Y-m-d H:i:s');
      
        try
        {
          if ($_data = $this->getRequest()->getPost())
          {
               $_territoryId = $this->getRequest()->getParam('id');
                  $dataset = array();
                  
               if (isset($_territoryId) && $_territoryId != "")
                {
                    $_territory = Mage::getModel('salesPerson/territory')->load($_territoryId, 'territory_id');
                      
                    $_territory->setData('territory_name', $_data['territory_name']);
                    $_territory->setData('territory_desc', $_data['territory_desc']);
                    $_territory->setData('territory_country', $_data['territory_country']);
                    $_territory->setData('updated_at',$timeNow);
                     
                    if ( $_territory->save())
                    {
                    Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('I95Dev_SalesPerson')->__('Territory has been saved'));
                    }
                    else
                    {
                    Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Territory failed to updated in GP'));
                    }
                }
                else
                {   
                  $_salesPerson = Mage::getModel('salesPerson/territory') 
                                          ->setTerritoryName($this->getRequest()->getParam('territory_name'))
                                          ->setTerritoryDesc($this->getRequest()->getParam('territory_desc'))
                                          ->setTerritoryCountry($this->getRequest()->getParam('territory_country'))
                          ->setCreatedAt($timeNow)
                          ->setUpdatedAt($timeNow);
                                          //->save();
                  
                if ($_salesPerson->save())
                    {
                    Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('I95Dev_SalesPerson')->__('Territory has been saved'));
                    }
                    else
                    {
                    Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Territory failed to updated in GP'));
                    }
                }

              if ($this->getRequest()->getParam('back'))
               {
                  $this->_redirect('*/*/edit', array('id' => $_salesPerson->getId()));
                  return;
               }

          }
           }
           catch(Exception $e)
           {
              Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
           }
          $this->_redirect('*/*/');

        
    }
    
    /** 
     * Delete Action
     * This is the Delete Action 
     */
    
    public function massDeleteAction()
    { 
       
        $territoryIds = $this->getRequest()->getParam('territory_id');   
        
        if(!is_array($territoryIds))
        {
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('salesPerson/territory')->__('Please select territories '));
        } 
        else
        {
            try
            {
                $territoryModel = Mage::getModel('salesPerson/territory');
                foreach ($territoryIds as $territoryId) 
                {
                    $territoryModel->load($territoryId)->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                Mage::helper('I95Dev_SalesPerson')->__('Total of %d record(s) were deleted.', count($taxIds)
            )
            );
        }
        catch (Exception $e)
        {
        Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
        }
        }
        $this->_redirect('*/*/index');
         
    }
    
    /**
     * Export territory grid to CSV format
     */
     public function exportCsvAction()
    {
        $fileName = 'territory.csv';
        $grid = $this->getLayout()->createBlock('salesPerson/adminhtml_territory_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }

    /**
     *  Export territoy grid to Excel XML format
     */
    public function exportExcelAction()
    {
        $fileName = 'territory.xml';
        $grid = $this->getLayout()->createBlock('salesPerson/adminhtml_territory_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }
  
}