<?php
class I95Dev_SalesPerson_Model_Roles extends Mage_Core_Model_Abstract
{

    
    public function toOptionArray($isMultiselect=false)
    {
         
                $roles = Mage::getModel('admin/roles')->getCollection();
                 $options = array();
                 
                      foreach($roles as $role)
                      {
              			  $option_id = $role->getData('role_id');
              			  $value= $role->getData('role_name');
              			  $options[] = array('value'=>"$option_id", 'label'=>"$value");
                      }
             

        return $options;
    
   }
}

?>