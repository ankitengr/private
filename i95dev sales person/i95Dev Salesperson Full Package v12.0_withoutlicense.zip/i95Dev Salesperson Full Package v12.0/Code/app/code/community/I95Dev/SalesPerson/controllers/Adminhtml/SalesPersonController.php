<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Adminhtml_SalesPersonController extends Mage_Adminhtml_Controller_action
{

    protected $_id;
    protected $_salesPersonModel;
    protected $_data;
    protected $_salesPersonRoleID;
    protected $_user;
    protected $_userID;
    protected $_result;
    protected $_salesPersonIds;
    protected $_salesPersonId;
    protected $_salesPerson;
    protected $_spCollection;
    protected $_customerERPmethod;
    protected $_customerWebURL;
    protected $_custParamValues;
    protected $customerParams;
    protected $_customerERPResult;
    protected $_customerResultData;
    protected $_customerERPKey;
    protected $_customerERPID;

    /**
     * Function to initialize action 
     */
    protected function _initAction()
    {
        $this->loadLayout()
                ->_setActiveMenu('salesPerson/items')
                ->_addBreadcrumb(Mage::helper('adminhtml')
                ->__('Items Manager'), Mage::helper('adminhtml')->__('Item Manager'));
        return $this;
    }

    /**
     * Function to index Action
     */
    public function indexAction()
    {
    	if (!Mage::helper('I95Dev_SalesPerson')->isAllowed())
    	{
    		$this->getResponse()->setRedirect(Mage::getBaseUrl() . "admin");
    	
    		Mage::getSingleton('core/session')->addError('Enable the Extension');
    		return $this;
    	}
        
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person'))
             ->_title(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person Users'));
          $this->_initAction(); 
        $this->_addContent(
               $this->getLayout()
                    ->createBlock('I95Dev_SalesPerson_Block_Adminhtml_SalesPerson')
                          );
        $this->renderLayout();
    }

    /**
     * Function to edit action
     */
    public function editAction()
    {
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Sales Person")); 
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Edit Sales Person"));
         
        $_id = $this->getRequest()->getParam('id');
        
        $_salesPersonModel = Mage::getModel('salesPerson/salesPerson_salesPerson')->load($_id);

        if ($_salesPersonModel->getId() || $_id == 0)
        {

            $_data = Mage::getSingleton('adminhtml/session')->getFormData(true);

            if (!empty($_data))
            {
                $_salesPersonModel->setData($_data);
            }
            Mage::register('salesPerson_data', $_salesPersonModel);
            $this->loadLayout();  
            
            $this->_setActiveMenu('salesPerson/items');
            $this->_addBreadcrumb(Mage::helper('adminhtml')
                    ->__('User Manager'), Mage::helper('adminhtml')
                    ->__('User Manager'));
             
            
            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);

            $this->_addContent($this->getLayout()->createBlock('salesPerson/adminhtml_salesPerson_edit'))
                    ->_addLeft($this->getLayout()->createBlock('salesPerson/adminhtml_salesPerson_edit_tabs'));
            
            
            $this->renderLayout();
        }
        else
        {
            Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Item does not exist'));
            $this->_redirect('*/*/');
        }
    }

    /**
     * Function for new action
     */
    public function newAction()
    { 
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Sales Person"));
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("Sales Person"));
        $this->_title(Mage::Helper('I95Dev_SalesPerson')->__("New Sales Person"));
        $this->_redirect('salesPerson/adminhtml_salesPerson/edit');
    }

    /**
     * Saving Salesperson User to Salesperson Role
     */
    public function saveAction()
    {
      $_data = $this->getRequest()->getPost();
      $timeNow =  date('Y-m-d H:i:s');
      
      try{
        if ($_data = $this->getRequest()->getPost())
        {
            $_data['salesperson_id'] = $this->getRequest()->getParam('id');
             
            $_salesPersonRoleID = $_data['rolename'];
            $_data['key'] = '';
            if ($this->getRequest()->getParam('id') == '')
            {
                $_user = Mage::getModel('admin/user')
                                ->setData(array(
                                    'username' => $_data['username'],
                                    'firstname' => $_data['firstname'],
                                    'lastname' => $_data['lastname'],
                                    'email' => $_data['email'],
                                    'password' => $_data['password'],
                                    'is_active' => 1
                                ))->save();
                $_user->setRoleIds(array($_salesPersonRoleID))
                        ->setRoleUserId($_user->getUserId())
                        ->saveRelations();
                $_userID = $_user->getUserId();

                if (isset($_userID) && $_userID != "")
                {
                    $_data['region_name'] = Mage::getModel('directory/region')->load($_data['state'])->getCode();
                    
                    //$_result = Mage::getModel('salesPerson/salesPerson')->ERPMappingData($_data);
                    
                        $_salesPerson = Mage::getModel('salesPerson/salesPerson')
                                        ->setData(array(
                                            'magento_id' => $_userID,
                                            'username' => $_data['username'],
                                            'firstname' => $_data['firstname'],
                                            'middlename' => $_data['middlename'],
                                            'lastname' => $_data['lastname'],
                                            'email' => $_data['email'],
                                            'commission' => $_data['commission'],
                                            'territory_id' => $_data['territory_id'],
                                            'commission_applied_on' => $_data['commission_applied_on'],
                                            'total_commission' => $_data['total_commission'], 
                                            'key' => $_result['Key'],
                                            'code' => $_data['code'],
                                            'status' => $_data['is_active'],
                                            'address1' => $_data['streetaddress1'],
                                            'address2' => $_data['streetaddress2'],
                                            'address3' => $_data['streetaddress3'],
                                            'address4' => $_data['streetaddress4'],
                                            'zip_code' => $_data['zip_code'],
                                            'city' => $_data['city'],
                                            'country' => $_data['country'],
                                            'state' => $_data['state'],
                                            'phone1' => $_data['phone1'],
                                            'phone2' => $_data['phone2'],
                                            'phone3' => $_data['phone3'],
                                            'fax' => $_data['fax'], 
                                            'created_at'=> $timeNow,
                                            'updated_at'=> $timeNow,
                                        )); 

                    if ($_salesPerson->save())
                    {
                        Mage::getSingleton('adminhtml/session')->addSuccess(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person has been saved'));
                        Mage::getSingleton('adminhtml/session')->setFormData(true);
                    }
                    else
                    {
                       Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person failed to Create '));
                    }
                }
            }
            else
            {
                $_salesPerson = Mage::getModel('salesPerson/salesPerson')
                        ->load($this->getRequest()->getParam('id'), 'salesPerson_id');
                $_salesPersonData = $_salesPerson->getData();
                $_data['username'] = $_salesPersonData['username'];
                $_user = Mage::getModel('admin/user')->load($_salesPersonData['magento_id']);
                $_salesPersonData['key'] = $_salesPersonData['key'];

                if (!empty($_data['password']) && isset($_data['password']))
                {
                    $_user->setData('password', $_data['password']);
                }
                
                /* saving salesperson data in magento */
                $_user->setData('username', $_data['username']);
                $_user->setData('firstname', $_data['firstname']);
                $_user->setData('lastname', $_data['lastname']);
                $_user->setData('email', $_data['email']);

                $_user->setData('is_active', $_data['is_active']);

                $_user->save();
                
                $_user->setRoleIds(array($_salesPersonRoleID))
                        ->setRoleUserId($_user->getUserId())
                        ->saveRelations();

                 

                    $_salesPerson->setData('username', $_data['username']);
                    $_salesPerson->setData('firstname', $_data['firstname']);
                    $_salesPerson->setData('lastname', $_data['lastname']);
                    $_salesPerson->setData('email', $_data['email']);
                    $_salesPerson->setData('commission', $_data['commission']); 

                    $_salesPerson->setData('address1', $_data['streetaddress1']);
                    $_salesPerson->setData('address2', $_data['streetaddress2']);
                    $_salesPerson->setData('address3', $_data['streetaddress3']);
                    $_salesPerson->setData('address4', $_data['streetaddress4']);
                    $_salesPerson->setData('zip_code', $_data['zip_code']);
                    $_salesPerson->setData('city', $_data['city']);
                    $_salesPerson->setData('state', $_data['state']);
                    $_salesPerson->setData('country', $_data['country']);
                    $_salesPerson->setData('phone1', $_data['phone1']);
                    $_salesPerson->setData('phone2', $_data['phone2']);
                    $_salesPerson->setData('phone3', $_data['phone3']);
                    $_salesPerson->setData('fax', $_data['fax']);
                    $_salesPerson->setData('middlename', $_data['middlename']);


                    $_salesPerson->setData('territory_id', $_data['territory_id']);
                    $_salesPerson->setData('commission_applied_on', $_data['commission_applied_on']); 
                    $_salesPerson->setData('status', $_data['is_active']);

 
                    $_salesPerson->setData('code', $_data['code']);
                    $_salesPerson->setData('key', $_result['Key']);
                     
                    $_salesPerson->setData('updated_at', $timeNow); 
                    
                   // $_salesPerson->save();
                if ($_salesPerson->save())
                {
                    Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('I95Dev_SalesPerson')->__('Salesperson has been saved'));
                }
                else
                {
                    Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Salesperson failed to updated in GP'));
                }
            }
            
            if ($this->getRequest()->getParam('back')) {
					       $this->_redirect('*/*/edit', array('id' => $_salesPerson->getId()));
					       return;
				       } 
        }
         }
         catch(Exception $e)
         {
            Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
         }
        $this->_redirect('*/*/');
    }

    /**
     * Function to delete sales person
     */
    public function deleteAction()
    {
        if ($this->getRequest()->getParam('id') > 0)
        {
            try
            {
                $_salesPersonModel = Mage::getModel('salesPerson/salesPerson');

                $_salesPersonModel->setId($this->getRequest()->getParam('id'))
                        ->delete();

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Item was successfully deleted'));
                $this->_redirect('*/*/');
            }
            catch (Exception $e)
            {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('*/*/');
    }

    /**
     * Function to mass delete sales persons
     */
    public function massDeleteAction()
    {
        $_salesPersonIds = $this->getRequest()->getParam('salesPerson');
        if (!is_array($_salesPersonIds))
        {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select item(s)'));
        }
        else
        {
            try
            {
                foreach ($_salesPersonIds as $_salesPersonId)
                {
                    $_salesPerson = Mage::getModel('salesPerson/salesPerson')->load($_salesPersonId);
                    $_salesPerson->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                        Mage::helper('adminhtml')->__(
                                'Total of %d record(s) were successfully deleted', count($_salesPersonIds)
                        )
                );
            }
            catch (Exception $e)
            {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    /**
     * Function for mass status action
     */
    public function massStatusAction()
    {
        $_salesPersonIds = $this->getRequest()->getParam('salesPerson');
        if (!is_array($_salesPersonIds))
        {
            Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Please select item(s)'));
        }
        else
        {
            try
            {
                foreach ($_salesPersonIds as $_salesPersonId)
                {
                    $salesPerson = Mage::getSingleton('I95Dev_NavConnector/navConnector_salesPerson')
                            ->load($_salesPersonId)
                            ->setStatus($this->getRequest()->getParam('status'))
                            ->setIsMassupdate(true)
                            ->save();
                }
                $this->_getSession()->addSuccess(
                        Mage::Helper('I95Dev_SalesPerson')->__('Total of %d record(s) were successfully updated', count($_salesPersonIds))
                );
            }
            catch (Exception $e)
            {
                $this->_getSession()->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    /**
     * Customer Salesperson Assignment action
     */
    public function assigncsrAction()
    {
        $this->loadLayout();
        $block = $this->getLayout()->createBlock('salesPerson/adminhtml_adminform', 'admin_form');
        $this->getLayout()->getBlock('content')->append($block);
        $this->renderLayout();
    }

    /**
     * Saving Salesperson ID to Customer
     */
    public function savecsrAction()
    {
        //Checking if the plugin is allowed to work
        $_helperERP = Mage::Helper('I95Dev_SalesPerson');
        $_data = $this->getRequest()->getPost();
        $targetCustomerId = (isset($_data['userid']) ? $_data['userid'] : ''); 
        $filterData = Mage::getModel('customer/customer')->getCollection()->addAttributeToFilter('target_customer_id', $targetCustomerId);
        $customerData = $filterData->getData();
        $customerId = (isset($customerData[0]['entity_id']) ? $customerData[0]['entity_id'] : '');
        $_customerObject = Mage::getModel('customer/customer')->load($customerId);
        $salesPersonCode = $_data['salesperson_code'];
        $_salesPersonObject= Mage::getModel('salesPerson/salesPerson_salesPerson')->load($salesPersonCode,'username');

        $_data['territoryid'] = $_salesPersonObject->getTerritoryID();
        $_data['salespersonid'] = $_salesPersonObject->getUsername();
        Mage::helper('I95Dev_SalesPerson')->loadClass('CustomerSalesPersonEntity');
        $customerEntity = new CustomerSalesPersonEntity();
        
        $salesPerson6Object = Mage::getModel('salesPerson/salesPerson_salesPerson6');

        $customerEntity->setSalesPerson($salesPerson6Object->getSalesPersonDataById($_salesPersonObject->getId()));
        $_result = $_helperERP->_doSoapCall($customerEntity, "AssignSalesPersontoCustomer", "CustomerData");

        $customerResponse = (isset($_result->AssignSalesPersontoCustomerResult) ? $_result->AssignSalesPersontoCustomerResult : $_result);
        
        if (!empty($decryptResponse) && $decryptResponse->Result == 1)
        {
            $_customerObject->setData('erp_salesperson_code', $_data['salespersonid']);
            $_customerObject->save();
            Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Customer successfully assigned to Sales Person'));
        }
        else
        {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Customer not assigned to Sales Person'));
        }
        $this->getResponse()->setRedirect($this->getUrl('*/customer'));
    }
    
    /**
     * Export order grid to CSV format
     */
    public function exportCsvAction()
    {   
        $fileName = 'salesperson.csv';
        $grid = $this->getLayout()->createBlock('salesPerson/adminhtml_salesPerson_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }  
       
    /** 
     *  Export order grid to Excel XML format 
     *  Export order Grid to Excel XML Format
     */  
         
    public function exportExcelAction()
    {   
        $fileName = 'salesperson.xml';
        $grid = $this->getLayout()->createBlock('salesPerson/adminhtml_salesPerson_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }    

     
}
