<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Model_SalesPerson extends Mage_Core_Model_Abstract
{
    const ERP_CREATE_METHOD = 'Create';
    const ERP_UPDATE_METHOD = 'Update';

    protected $_helperERP;
    protected $_salesPersonParamsValues;
    protected $_salesPersonSalesPersonURL;
    protected $_helperSalesPerson;
    protected $_salesPersonParams;
    protected $_readMultipleMethod;
    protected $_salesPersonID;
    public    $ERPresponse;
    protected $_salespersonData;
    protected $_magentoSalespersonValues;

    /**
     * Function to initialize sales person
     */
    public function _construct()
    {
        parent::_construct();
        $this->_init('salesPerson/salesPerson');
    }

    /**
     * Getting the data from ERP
     * @param type $data
     * @return type 
     */
    public function ERPMappingData($data)
    {
        $_salesPersonID = $data['salesperson_id'];

        try
        {  
            $_salespersonData = (array) $data;
        }
        catch (Exception $ex)
        {
            
        }
        return $_salespersonData;
    }

    /**
     * Getting the data from ERP
     * @params $data
     * @return $_salespersonData
     */
    public function ERPSPMappingData($data, $param, $entity, $serviceCall, $responseResult)
    {
        $_salesPersonID = $data['salesperson_id'];

        try
        {

            $helper = Mage::Helper('I95Dev_SalesPerson');
            $args = array('entity' => $entity, 'param' => $param, 'salespersonData' => $data);

            $ERPresponse = $helper->_makeServiceCall($serviceCall, $args);
            $_salespersonData = (array) $ERPresponse->$responseResult;
        }
        catch (Exception $ex)
        {
            
        }

        return $_salespersonData;
    }

    /**
     * mapping the GP salesperson to Magento
     * @param type $data
     * @return type 
     */
    public function mapERPSalespersonData($data)
    {
        try
        {
            if (isset($data['key']) && $data['key'] != '')
            {
                $_magentoSalespersonValues['Key'] = $data['key'];
            }
            $_magentoSalespersonValues['Code'] = $data['code'];
            $_magentoSalespersonValues['Name'] = $data['firstname'] . $data['lastname'];
            $_magentoSalespersonValues['Commission_Percent'] = $data['commission'];
            $_magentoSalespersonValues['E_Mail'] = $data['email'];
        }
        catch (Exception $ex)
        {
            
        }
        return $_magentoSalespersonValues;
    }


}