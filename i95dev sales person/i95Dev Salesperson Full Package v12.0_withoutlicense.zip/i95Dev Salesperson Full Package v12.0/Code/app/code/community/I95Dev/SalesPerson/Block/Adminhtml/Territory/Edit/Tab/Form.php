<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Territory_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Function to get Commisions Applied
     * @return string 
     */
    public function getCommisionsApplied()
    {
        //commisions
        $commissionAppliedOn = Mage::getStoreConfig('salespersontab/advanced/commissionappliedon');
        $commissionAppliedValues = explode(',', $commissionAppliedOn);
        $commissionApplied = array();
        foreach ($commissionAppliedValues as $commissionAppliedValue)
        {
            $commissionApplied[] =
                    array('value' => $commissionAppliedValue, 'label' => '  ' . ucfirst($commissionAppliedValue) . '  ');
        }
        return $commissionApplied;
    }

    /**
     * Function to get Default Commission
     * @return type 
     */
    public function getDefaultCommission()
    {
        $defaultCommission = Mage::getStoreConfig('salespersontab/advanced/defaultcommissionappliedon');
        return $defaultCommission;
    }

    /**
     * prepare Form
     * @return type 
     */
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        
        $magentoAdminUser = "";
        $magentoAdminUserUrl = "";
        $this->setForm($form);
        $territoryid = Mage::app()->getRequest()->getParam('id');
        $User = Mage::getModel('salesPerson/territory')->load($territoryid, 'territory_id');
        $userData = $User->getData(); 

         $form->setHtmlIdPrefix('user_');
        $fieldset = $form->addFieldset('base_fieldset', array('legend' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Info')));
         
           /**
        $fieldset->addField('territory_id', 'text', array(
            'name' => 'territory_id',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Territory ID'),
            'id' => 'territory_id',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('Territory ID'),
            'required' => true
        ));**/  
        $fieldset->addField('territory_name', 'text', array(
            'name' => 'territory_name',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Name'),
            'id' => 'territory_name',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Name'),
             'required' => true
        ));
        
        $fieldset->addField('territory_desc', 'text', array(
            'name' => 'territory_desc',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Description'),
            'id' => 'territory_desc',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Description'),
            'required' => true,
        )); 
        
        
        $fieldset->addField('territory_country', 'text', array(
            'name' => 'territory_country',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Country'),
            'id' => 'territory_country',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Country'),
            'required' => true,
        )); 
         
        
        $form->setValues($userData);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Options getter
     * @return array 
     */
    public function toTerritoryOptionArray()
    {
        
        $territoryData = array();
        $allTerritories = array();
        $territoryCollection = Mage::getModel("salesPerson/territory")->getCollection(); 
        
        foreach ($territoryCollection->getData() as $territoryData)
        {
            $allTerritories[] = array('value' => $territoryData['territory_name'], 'label' => $territoryData['territory_name']);
        }
        return $allTerritories;
    }

}
