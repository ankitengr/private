<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_SalesPerson_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Function to get Commisions Applied
     * @return string 
     */
    public function getCommisionsApplied()
    {
        //commisions
        $commissionAppliedOn = Mage::getStoreConfig('salespersontab/advanced/commissionappliedon');
        $commissionAppliedValues = explode(',', $commissionAppliedOn);
        $commissionApplied = array();
        foreach ($commissionAppliedValues as $commissionAppliedValue)
        {
            $commissionApplied[] =
                    array('value' => $commissionAppliedValue, 'label' => '  ' . ucfirst($commissionAppliedValue) . '  ');
        }
        return $commissionApplied;
    }

    /**
     * Function to get Default Commission
     * @return type 
     */
    public function getDefaultCommission()
    {
        $defaultCommission = Mage::getStoreConfig('salespersontab/advanced/defaultcommissionappliedon');
        return $defaultCommission;
    }

    /**
     * prepare Form
     * @return type 
     */
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $magentoAdminUser = "";
        $magentoAdminUserUrl = ""; 
        $this->setForm($form);
        $userid = Mage::app()->getRequest()->getParam('id');
        $User = Mage::getModel('salesPerson/salesPerson_salesPerson')->load($userid, 'salesperson_id');
        $userData = $User->getData();
        $totalCommission = (isset($userData['total_commission']) ? $userData['total_commission'] : 0);
        $username_flag = false;

        $commissionApplied = $this->getCommisionsApplied();
        $defaultCommission = $this->getDefaultCommission();

        if (!empty($userData))
        {
            $username = $userData['username'];
            if (trim($username))
            {
                $magentoAdminUser = Mage::getModel('admin/user')->load($userData['magento_id'])->getUsername();
                $magentoAdminUserUrl = Mage::helper('adminhtml')->getUrl('adminhtml/permissions_user/edit/', array('user_id' => $userData['magento_id'])
                );
            }

            $firstname = $userData['firstname'];
            $lastname = $userData['lastname'];
            $middlename = $userData['middlename'];
            $email = $userData['email'];
            $commission = $userData['commission'];
            $code = $userData['code'];
            $territory_id = $userData['territory_id'];
            $is_active = $userData['status'];
            $username_flag = true;
        }
        else
        {

            $username = '';
            $firstname = "";
            $lastname = "";
            $middlename = "";
            $email = "";
            $commission = '';
            $code = "";
            $is_active = 1;
            $territory_id = "";
            $username_flag = false; 
        }
        $form->setHtmlIdPrefix('user_');
        $fieldset = $form->addFieldset('base_fieldset', array('legend' => Mage::Helper('I95Dev_SalesPerson')->__('Sales Person Info')));
        $fieldset->addField('user_id', 'hidden', array(
            'name' => 'user_id',
        ));
        
        if($username)
        {
          $userNameType = "label";
        } 
        else
        {
          $userNameType = "text";
        }
        $fieldset->addField('username', $userNameType, array(
            'name' => 'username',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Sales Person User ID'),
            'id' => 'username',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('username'),
            'required' => true,
            'class' => 'input-text validate-length minimum-length-1 maximum-length-15',
            'value' => $username,
            'disabled' => $username_flag,
        ));

        if($username)
        { 
        $fieldset->addField('link', 'link', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Magento Admin User'),
            'after_element_html' => '<a href=' . $magentoAdminUserUrl . '>' . $magentoAdminUser . '</a>'
        ));
        }
        
       /* $fieldset->addField('code', 'text', array(
            'name' => 'code',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Code'),
            'id' => 'lastname',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('code'),
            'value' => $username,
        )); */
        
        $fieldset->addField('firstname', 'text', array(
            'name' => 'firstname',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('First Name'),
            'id' => 'firstname',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('firstname'),
            'required' => true,
        ));
        $fieldset->addField('middlename', 'text', array(
            'name' => 'middlename',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Middle Name'),
            'id' => 'middlename',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('middlename'),
        ));
        $fieldset->addField('lastname', 'text', array(
            'name' => 'lastname',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Last Name'),
            'id' => 'lastname',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('lastname'),
            'required' => true,
        ));
        $fieldset->addField('email', 'text', array(
            'name' => 'email',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Email'),
            'id' => 'customer_email',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('email'),
            'class' => 'required-entry validate-email',
            'required' => true,
        ));
        if ($userid == '')
        {
            $fieldset->addField('password', 'password', array(
                'name' => 'password',
                'label' => Mage::Helper('I95Dev_SalesPerson')->__('New Password'),
                'id' => 'customer_pass',
                'title' => Mage::Helper('I95Dev_SalesPerson')->__('newpasswd'),
                'class' => 'input-text required-entry validate-admin-password',
                'required' => true,
            ));
            $fieldset->addField('confirmation', 'password', array(
                'name' => 'password_confirmation',
                'label' => Mage::Helper('I95Dev_SalesPerson')->__('Confirm Password'),
                'id' => 'confirmation',
                'title' => Mage::Helper('I95Dev_SalesPerson')->__('confirmpasswd'),
                'class' => 'input-text required-entry validate-cpassword',
                'required' => true,
            ));
        }
        $fieldset->addField('territory_id', 'select', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Territory ID'),
            'value' => $territory_id,
            'required' => true,
            'name' => 'territory_id',
            'tabindex' => 1,
            'values' => $this->toTerritoryOptionArray(),
        ));
 
        $fieldset->addField('commission_applied_on', 'select', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Commission Applied'),
            'name' => 'commission_applied_on',
            'onclick' => "",
            'onchange' => "",
            'values' => Mage::getModel('salesPerson/system_config_source_CommissionAppliedOn')->toOptionArray(),
            'disabled' => false,

            'readonly' => false,
            'tabindex' => 3
        ));
        

        $fieldset->addField('commission', 'text', array(
            'name' => 'commission',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Commission %'),
            'id' => 'customer_email',
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('commission'),
            'class' => 'required-entry',
            'required' => true,
            'note' => 'Eg:2 (Do not exceed 100)',
        ));
        
        if($totalCommission != 0)
        {
        $fieldset->addField('total_commission', 'label', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Total Commission'),
            'name' => 'total_commission',
            'onclick' => "",
            'onchange' => "",
            'disabled' => false,
            'readonly' => false,
            'tabindex' => 4
        ));
        }
        

        $fieldset->addField('status', 'select', array(
            'name' => 'is_active',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Is Active'),
            'id' => 'is_active',
            'title' => Mage::helper('adminhtml')->__('Account Status'),
            'class' => 'input-select',
            'style' => 'width: 80px',
            'options' => array('1' => Mage::helper('adminhtml')->__('Yes'), '0' => Mage::helper('adminhtml')->__('No')),
            'value' => $is_active,
        ));
        $fieldset->addField('user_roles', 'hidden', array(
            'name' => 'user_roles',
            'id' => '_user_roles',
            'value' => 'Salesperson',
        ));

        $form->setValues($userData);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Options getter
     * @return array 
     */
    public function toTerritoryOptionArray()
    {
        $territoryCollection = array();
        $territoryData = array();
        $allTerritories = array();
        $territoryCollection = Mage::getModel("salesPerson/territory")->getCollection();
        foreach ($territoryCollection->getData() as $territoryData)
        {
            $allTerritories[] = array('value' => $territoryData['territory_name'], 'label' => $territoryData['territory_name']);
        }
        return $allTerritories;
    }

}
