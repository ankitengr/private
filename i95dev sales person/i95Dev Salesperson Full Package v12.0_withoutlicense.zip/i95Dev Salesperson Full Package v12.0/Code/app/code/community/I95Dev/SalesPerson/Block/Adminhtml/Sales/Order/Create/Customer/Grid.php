<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Sales_Order_Create_Customer_Grid extends Mage_Adminhtml_Block_Sales_Order_Create_Customer_Grid
{

    /**
     * Setting the Default ERP To Magento Events Grid form values
     */
    public function __construct()
    {

        parent::__construct();
        $this->setId('sales_order_create_customer_grid');
        $this->setRowClickCallback('order.selectCustomer.bind(order)');
        $this->setUseAjax(true);
        $this->setDefaultSort('entity_id');
    }

    /**
     * Showing Salesperson Agent in Order crid.
     * @return type 
     */
    protected function _prepareCollection()
    {
        $collection = Mage::getResourceModel('customer/customer_collection')
                ->addNameToSelect()
                ->addAttributeToSelect('email')
                ->addAttributeToSelect('created_at')
                ->joinAttribute('billing_postcode', 'customer_address/postcode', 'default_billing', null, 'left')
                ->joinAttribute('billing_city', 'customer_address/city', 'default_billing', null, 'left')
                ->joinAttribute('billing_telephone', 'customer_address/telephone', 'default_billing', null, 'left')
                ->joinAttribute('billing_regione', 'customer_address/region', 'default_billing', null, 'left')
                ->joinAttribute('billing_country_id', 'customer_address/country_id', 'default_billing', null, 'left')
                ->joinField('store_name', 'core/store', 'name', 'store_id=store_id', null, 'left');

        //Code to identify whether login user is salesperson or not and displaying orders of that saleperson

        $_salesPersonRoleID = Mage::Helper('I95Dev_SalesPerson/salesPerson')->getSalesPersonRoleID();
        $session_user = Mage::getSingleton('admin/session')->getUser();
	    $usrRoleId = $session_user->getRole()->getRoleId();
	    $usrName = $session_user->getData('username');

        if ($usrRoleId == $_salesPersonRoleID)
        {
            $_salesPerson = Mage::getModel('salesPerson/salesPerson')
                    ->load($usrName, 'username');
            $collection->addAttributeToFilter('erp_salesperson_code', $_salesPerson->getUsername());
        }
        $this->setCollection($collection);

        return Mage_Adminhtml_Block_Widget_Grid::_prepareCollection();
    }

}
