<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Territory_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

    /**
     * Function for sales person edit tab constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('territory_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(Mage::Helper('I95Dev_SalesPerson')->__('Territory Information'));
    }

    /**
     * Preparing Tabs for Salesperson Menu
     * @return type 
     */
    protected function _beforeToHtml()
    {

        $this->addTab('form_section', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Info'),
            'title' => Mage::Helper('I95Dev_SalesPerson')->__('Territory Info'),
            'content' => $this->getLayout()->createBlock('salesPerson/adminhtml_territory_edit_tab_form')->toHtml(),
        )); 
        return parent::_beforeToHtml();
    }

}