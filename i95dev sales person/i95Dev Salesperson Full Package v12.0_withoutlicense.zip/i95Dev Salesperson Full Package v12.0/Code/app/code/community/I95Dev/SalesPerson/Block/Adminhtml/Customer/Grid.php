<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */

class I95Dev_SalesPerson_Block_Adminhtml_Customer_Grid extends Mage_Adminhtml_Block_Customer_Grid
{

    /**
     * Displaying Salesperson Agent in the Customer Grid
     * @return type 
     * 
     * 
     */
    
     public function __construct()
    {
        parent::__construct();
        $this->setId('customerGrid');
        $this->setUseAjax(true);
        $this->setDefaultSort('entity_id');
        $this->setSaveParametersInSession(true);
    }
    
    protected function _prepareCollection()
    {
       
       //parent::_prepareCollection();  
        $collection = Mage::getResourceModel('customer/customer_collection')
                ->addNameToSelect()
                ->addAttributeToSelect('email')
                ->addAttributeToSelect('created_at')
                ->addAttributeToSelect('group_id')
                ->addAttributeToSelect('erp_salesperson_code') 
                ->joinAttribute('billing_postcode', 'customer_address/postcode', 'default_billing', null, 'left')
                ->joinAttribute('billing_city', 'customer_address/city', 'default_billing', null, 'left')
                ->joinAttribute('billing_telephone', 'customer_address/telephone', 'default_billing', null, 'left')
                ->joinAttribute('billing_region', 'customer_address/region', 'default_billing', null, 'left')
                ->joinAttribute('billing_country_id', 'customer_address/country_id', 'default_billing', null, 'left');
         
       
        $usr = Mage::getSingleton('admin/session')->getUser();
        $userName = $usr->getUsername();
        $usrRoleId = $usr->getRole()->getRoleId();
        
        
         $_salesPerson = Mage::getModel('salesPerson/salesPerson')
                    ->load($userName, 'username');
          
         $id = $_salesPerson['username'];//->getSalesPersonId();
          

        /* checking user role id and salesperson role id are same */
        if ($usrRoleId != 1)
        {
             $collection->addAttributeToFilter('erp_salesperson_code',$id);
              
        }
         

        $this->setCollection($collection);

        //return $this;
        return Mage_Adminhtml_Block_Widget_Grid::_prepareCollection();
    }
    
    protected function _prepareColumns()
    {
       
        $this->addColumnAfter('salesperson', array(
            'header'    => Mage::helper('I95Dev_SalesPerson')->__('Sales Person Id'),
            'width'     => '50',
            'index'     => 'erp_salesperson_code',
            	),'name');
        
        return  parent::_prepareColumns(); 
    }

}
?>