<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Assigncsr_Csr_Form extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Prepare Form for Assinging Salesperson
     * 
     */ 
    protected function _prepareForm()
    {
        if (Mage::getSingleton('adminhtml/session')->getSalespersonData())
        {
            $data = Mage::getSingleton('adminhtml/session')->getSalespersonlData();
            Mage::getSingleton('adminhtml/session')->getSalespesonData(null);
        }
        elseif (Mage::registry('salesperson_data'))
        {
            $data = Mage::registry('salesperson_data')->getData();
        }
        else
        {
            $data = array();
        }

        $form = new Varien_Data_Form(array(
                    'id' => 'edit_form',
                    'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
                    'method' => 'post',
                    'enctype' => 'multipart/form-data',
                ));

        $form->setUseContainer(true);
        $orderids = Mage::registry('orderid');
        
        //$salespersonids = Mage::registry('salespersonid');
        
        $collection = Mage::getModel('salesPerson/salesPerson_salesPerson')
                  ->getCollection()
                  ->addFieldToSelect('username') 
                  ->addFieldToSelect('salesPerson_id')
                  ->addFieldToFilter('status', '1')
                  ->getData();
         $_arrSalesPerson[] = array('value' => '', 'label' => 'Select Sales Person ID');
          
           foreach ($collection as $_salespersonData)
            {
                $_arrSalesPerson[] = array('value' => $_salespersonData['username'], 'label' => $_salespersonData['username']);
            }
           
        
        
        $fieldset = $form->addFieldset('salesperson_form', array(
            'legend' => Mage::Helper('I95Dev_SalesPerson')->__("Assign Sales Person to Order")
                ));

        $fieldset->addField('order_id', 'select', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Order ID'),
            'class' => 'required-entry',
            'name' => 'order_id',
            'required' => true,
            'values' => $orderids,
        ));

        $fieldset->addField('salesperson_id', 'select', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Sales Person ID'),
            'class' => 'input-select',
            'required' => true,
            'name' => 'salesperson_id',
            'value' => 'Select Salesperson ID',
            'values' => $_arrSalesPerson,
        ));
        $this->setForm($form);
        return parent::_prepareForm();
    }

}