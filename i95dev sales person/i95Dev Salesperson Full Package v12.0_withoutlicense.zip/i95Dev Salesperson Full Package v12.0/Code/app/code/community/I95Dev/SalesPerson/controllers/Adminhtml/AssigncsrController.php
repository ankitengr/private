<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Adminhtml_AssigncsrController extends Mage_Adminhtml_Controller_action
{
    const ERP_UPDATE_METHOD = 'Update';

    protected $_block;
    protected $_orderData;
    protected $_orderId;
    protected $orderData;
    protected $_ERPOrderIDs;
    protected $_salespersonCollection;
    protected $_arrSalesPerson;
    protected $_request;
    protected $_salesPersonId;
    protected $_helperERP;
    protected $orderUpdateERPMethod;
    protected $_orderWebURL;
    protected $_orderParamValues;
    protected $_orderParams;
    protected $_orderERPResult;
    protected $_orderResultData;
    protected $_orderERPKey;
    protected $_orderERPID;

    
     protected function _initAction()
    {
         $this->loadLayout()
              ->_setActiveMenu("salesPerson/csr")
                  ->_addBreadcrumb(Mage::helper("adminhtml")
                  ->__("Assign Sales Person to Orders"), Mage::helper("adminhtml")->__("Assign Sales Person to Order"));
        return $this;
    }
    
    /**
     * Function for index action
     */
    
    public function indexAction()
    {
        //die('this is working here');
           
        $this->_title(Mage::helper('I95Dev_SalesPerson')->__("Sales Person"));
        $this->_title(Mage::helper('I95Dev_SalesPerson')->__("Assign Sales Person to Order"));
        
        $this->_initAction();
        try
        { 
            $_block = $this->getLayout()->createBlock('salesPerson/adminhtml_assigncsr_csr');
            $_orderData = Mage::getModel('sales/order')->getCollection()
                    ->addFieldToFilter('status', 'pending')
                    ->addFieldToFilter('total_item_count', array('gt' => 0))
                    ->getData(); 
            
            $_orderId = $this->getRequest()->getParam('order_id');
             
            if (!isset($_orderId) && empty($_orderId))
            {
                $orderData[] = array('value' => '', 
                                     'label' => Mage::Helper('I95Dev_SalesPerson')->__('Select  Order ID'));
                 
                 
                foreach ($_orderData as $_orders)
                {
                    $orderData[] = array(
                        'value' => $_orders['increment_id'],
                        'label' => $_orders['increment_id'],
                    );
                }
            }

            if (isset($_orderId) && !empty($_orderId))
            {

                $orderData[] = array('value' => $_orderId, 'label' => $_orderId);
            }
            Mage::register('orderid', $orderData);
            
            $_salespersonCollection = Mage::getModel('salesPerson/salesPerson')
                                    ->getCollection()
                                    ->addFieldToFilter('status', '1')->getData();
            
            $_arrSalesPerson[] = array('value' => '', 'label' =>'Select Sales Person');
            
            foreach ($_salespersonCollection as $_salespersonData)
            {
                $_arrSalesPerson[] = array('value' => $_salespersonData['salesPerson_id'], 'label' => $_salespersonData['username']);
            }

            Mage::register('salespersonid', $_arrSalesPerson);
            $this->getLayout()->getBlock('content')->append($_block);
        }
        catch (Exception $e)
        {
            Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            return;
        }

        if ($this->getRequest()->getParam('back'))
        {
            $this->_redirect('*/*/edit', array('id' => $userid));
            return;
        }
        $this->renderLayout();
    }

    /**
     * Saving order assignments
     * 
     */
    public function saveAction()
    {
        
        
        $this->loadLayout();
        $request = $this->getRequest()->getPost(); 
        
        $helperERP = Mage::Helper('I95Dev_SalesPerson');
        
        $orderId = $this->getRequest()->getParam('order_id');
        $salesPersonId = $this->getRequest()->getParam('salesperson_id');
         
        
        $order = Mage::getModel('sales/order')->getCollection()
                ->addFieldToFilter('increment_id', $orderId)
                ->getFirstItem();
        
         
         
        $salesPersonObject = Mage::getModel('salesPerson/salesPerson_salesPerson')
                            ->load($salesPersonId,'username');
        
        $salesPersonCommsion = $salesPersonObject->getCommission();
        $salesPersonTotalCommision = $salesPersonObject->getTotalCommission();
        
        if($salesPersonTotalCommision == NULL)
        {
            $salesPersonTotalCommision =0;
        }
         
        $data['territoryid']=$salesPersonObject->getTerritoryID();
        $data['salespersonid']=$salesPersonObject->getUsername();
        $entityId = $order->getEntityId();
	$targetOrderId = $order->getIncrementId();
        try
        {
                 $_assCSR = Mage::getModel('sales/order')->load($orderId, 'increment_id');
                    
                 $orderGrandTotal = $_assCSR->getGrandTotal();
                  
                 $salesPersonTotalCommision = $salesPersonTotalCommision + $orderGrandTotal*$salesPersonCommsion/100;
                  
                 $orderCommission = $orderGrandTotal*$salesPersonCommsion/100;
                 
                 $salesPersonObject->setData('total_commission',$salesPersonTotalCommision);
                 
                 $salesPersonObject->save();
                  
                 $_assCSR->setData('erp_salesperson_code', $salesPersonId);
                 
                 $_assCSR->setData('salesperson_commission', $orderCommission);
                    
                 if ($_assCSR->save())
                 {
                   Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('I95Dev_SalesPerson')->__('Sales Person Saved'));
                 }
                 else
                 {
                    Mage::getSingleton('adminhtml/session')->addError(Mage::Helper('I95Dev_SalesPerson')->__('Sales Person not Saved'));
                 }
            
        }
        catch(Exception $e)
           {
              Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
           }
         
         $this->getResponse()->setRedirect($this->getUrl('adminhtml/sales_order/view/order_id/'.$_assCSR->getId()));
        
    }

}