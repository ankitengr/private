<?php


/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Assigncsr_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

    /**
     * Sales Person assign constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('assigncsrGrid');
        $this->setUseAjax(true);
        $this->setDefaultSort('entity_id');
        $this->setSaveParametersInSession(true);
    }


    /**
     * Prepares collection for customer grid
     * @return type 
     */
    protected function _prepareCollection()
    {
        return Mage_Adminhtml_Block_Widget_Grid::_prepareCollection();
    }


    /**
     * prepare columns
     * @return type 
     */
    protected function _prepareColumns()
    {
        parent::_prepareColumns();

        $this->addColumnAfter('erp_salesperson_code', array(
            'header' => Mage::helper('customer')->__('ERP Sales Person ID'),
            'width' => '80px',
            'type' => 'text',
            'renderer' => 'I95Dev_Salesperson_Block_Renderer_Csr',
            'filter_index' => 't2.erp_salesperson_code',
                ), 'billing_region');

        return Mage_Adminhtml_Block_Widget_Grid::_prepareColumns();
    }

}
