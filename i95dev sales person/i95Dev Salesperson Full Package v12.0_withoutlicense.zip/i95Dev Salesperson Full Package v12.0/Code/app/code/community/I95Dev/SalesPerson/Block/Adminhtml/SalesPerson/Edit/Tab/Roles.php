<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_SalesPerson_Edit_Tab_Roles extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Displaying roles in the form
     */
    protected function _prepareForm()
    {
        $salesPersonId = $this->getRequest()->getParam('id');
        $salesPersonData = Mage::getModel('salesPerson/salesPerson')->load($salesPersonId,'salesPerson_id');
        $roleData = Mage::getModel('admin/user')->load($salesPersonData['magento_id'])->getRole()->getData();
        
		if(isset($roleData['role_id']))
		{
		 $roleId = $roleData['role_id'];
		}
		else
		{
		 $roleId = '';
		}
				$allowedRoles = Mage::getStoreConfig('salespersontab/advanced/allowedroles');
                $alloweedRolesArray = explode(',',$allowedRoles); 
                $rolesNamesArray = array();
                for($i=0;$i<sizeOf($alloweedRolesArray);$i++)
                {
                  $rolesNamesArray[$alloweedRolesArray[$i]] = Mage::getModel('admin/roles')->load($alloweedRolesArray[$i])->getData('role_name');
                }
                
        $form = new Varien_Data_Form();
        $fieldset = $form->addFieldset('base_fieldset', array('legend' => Mage::Helper('I95Dev_SalesPerson')->__('Role')));

        
          $fieldset->addField('role_name', 'select', array(
            'name' => 'rolename',
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Role Name'),
            'id' => 'role_name',
            'class' => 'required-entry roles-pad',
            'value' => $roleId,
            'width' => '50px',
            'values'=> $rolesNamesArray,
            'required' => true,
                )
        );
        
        $fieldset->addField('in_role_user', 'hidden', array(
            'name' => 'in_role_user',
            'id' => 'in_role_userz',
                )
        );

        $fieldset->addField('in_role_user_old', 'hidden', array('name' => 'in_role_user_old'));
        $this->setForm($form);
    }

}