<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 * @Category       Salesperson
 * @Package        I95Dev_Salesperson
 * @Description    Assigning Salesperson to customer
 * @Author         I95Dev
 */
class I95Dev_SalesPerson_Helper_Data extends Mage_Core_Helper_Abstract
{

	/**
	 * Checking whether extention is enabled or not
	 * @return boolean
	 */
	function isAllowed()
	{
		$isEnabled = Mage::getStoreConfig('salespersontab/advanced/is_enabled');
		if ($isEnabled == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	} 
}