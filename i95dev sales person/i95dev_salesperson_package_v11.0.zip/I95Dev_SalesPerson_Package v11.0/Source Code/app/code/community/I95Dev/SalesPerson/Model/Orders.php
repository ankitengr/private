<?php

class I95Dev_SalesPerson_Model_Orders
extends Mage_Core_Model_Abstract 
{

    /**
     * Initialize the resource model collection
     */
   protected function _construct()
    {
       
        $this->_init('salesPerson/salesPerson');
    }
     

}
?>