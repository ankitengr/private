<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
/* Creating SalesPerson role */
$role = Mage::getModel("admin/roles")
        ->setName('salesperson')
        ->setRoleType('G')
        ->save();
/* Assigning order,invoice,creditmemo and customer permissions */
Mage::getModel("admin/rules")
        ->setRoleId($role->getId())
        ->setResources(array("admin/customer",
            "admin/customer/manage",
            "admin/sales",
            "admin/sales/order",
            "admin/sales/order/actions",
            "admin/sales/order/actions/create",
            "admin/sales/order/actions/create/reward_spend",
            "admin/sales/order/actions/view",
            "admin/sales/order/actions/email",
            "admin/sales/order/actions/reorder",
            "admin/sales/order/actions/edit",
            "admin/sales/order/actions/cancel",
            "admin/sales/order/actions/review_payment",
            "admin/sales/order/actions/capture",
            "admin/sales/order/actions/invoice",
            "admin/sales/order/actions/creditmemo",
            "admin/sales/order/actions/hold",
            "admin/sales/order/actions/unhold",
            "admin/sales/order/actions/ship",
            "admin/sales/order/actions/comment",
            "admin/sales/order/actions/emails",
            "admin/sales/invoice",
            "admin/sales/shipment"))
        ->saveRel();


