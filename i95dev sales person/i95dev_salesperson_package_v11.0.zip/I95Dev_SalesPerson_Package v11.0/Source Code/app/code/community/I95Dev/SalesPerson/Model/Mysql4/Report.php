<?php

class I95Dev_SalesPerson_Model_Mysql4_Report 
extends Mage_Core_Model_Mysql4_Collection_Abstract
{

    /**
     * Initialize the resource model collection
     */
    public function _construct()
    {
        parent::_construct();
        $this->_init('salesPerson/salesPerson','salesPerson_id');
    }

}
?>