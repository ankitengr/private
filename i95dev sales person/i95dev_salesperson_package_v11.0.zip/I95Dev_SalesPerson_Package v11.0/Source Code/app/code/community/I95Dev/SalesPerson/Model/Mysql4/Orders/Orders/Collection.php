<?php

class I95Dev_SalesPerson_Model_Mysql4_Orders_Orders_Collection 
extends Mage_Core_Model_Mysql4_Collection_Abstract 
{

    /**
     * Initialize the resource model collection
     */
    public function _construct()
    {
          
        $this->_init('salesPerson/salesPerson');
    }
    
    protected function _joinFields($from = '', $to = '')
    {
        $sales_order = Mage::getSingleton('core/resource')->getTableName('sales/order');
        $this->addFieldToSelect('username');
        $this->addFieldToSelect('salesPerson_id');
        $this->addFieldToSelect('total_commission');
         
        $this->getSelect()
              ->join(
                      array('sales_order'=>$sales_order),
                      'sales_order.erp_salesperson_code = main_table.username',
                      'sales_order.*'
                      );
        $this->addFieldToFilter('sales_order.created_at' , array("from" => $from, "to" => $to));
        $this->getSelect()->group('main_table.salesPerson_id');
        $this->getSelect()->columns(array('value' => 'count(main_table.username)'));
        //$this->getSelect()->columns(array('order_id' => 'sales_order.increment_id'));
        $this->getSelect()->columns(array('totalcomm' => 'sum(sales_order.salesperson_commission)'));
          
        return $this;
    }
     
 
    public function setDateRange($from, $to)
    {
        $this->_reset();
        $this->_joinFields($this->timeShift($from), $this->timeShift($to));
        return $this;
    }
 
    public function load($printQuery = false, $logQuery = false)
    {
        if ($this->isLoaded()) {
            return $this;
        }
        parent::load($printQuery, $logQuery);
         //die; 
        return $this;
    }
 
    public function setStoreIds($storeIds)
    {
        return $this;
    }
    
    public function timeShift($datetime)
   {
       return Mage::app()->getLocale()->utcDate(null, $datetime, true, Varien_Date::DATETIME_INTERNAL_FORMAT)->toString(Varien_Date::DATETIME_INTERNAL_FORMAT);
   }
    

    
    

}



?>
