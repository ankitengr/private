<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */

class I95Dev_SalesPerson_Block_Adminhtml_Customer_Edit_Tab_SalesPerson
extends Mage_Adminhtml_Block_Widget_Form
{ 
   
    public function __construct()
    {
        parent::__construct(); 
    }

    public function initForm()
    {
        $form = new Varien_Data_Form();
        $fieldset = $form->addFieldset('base_fieldset', array(
            'legend' => Mage::helper('customer')->__('Sales Person')
        ));
         
        $customer = Mage::registry('current_customer');
        $collection = Mage::getModel('salesPerson/salesPerson_salesPerson')
                  ->getCollection()
                  ->addFieldToSelect('username') 
                  ->addFieldToSelect('salesPerson_id')
                  ->addFieldToFilter('status', '1')
                  ->getData();
        
        
        if ($customer->getErpSalespersonCode())
        {
             $_arrSalesPerson[] = array('value' => $customer->getErpSalespersonCode(), 'label' => $customer->getErpSalespersonCode());
        
             foreach ($collection as $_salespersonData)
            {
                if($customer->getErpSalespersonCode()!=$_salespersonData['username'])
                { 
                   $_arrSalesPerson[] = array('value' => $_salespersonData['username'], 'label' => $_salespersonData['username']);
                }
            }
            
        }
        else
        {
        
         $_arrSalesPerson[] = array('value' => '', 'label' => 'Select Sales Person ID');
          
           foreach ($collection as $_salespersonData)
            {
                $_arrSalesPerson[] = array('value' => $_salespersonData['username'], 'label' => $_salespersonData['username']);
            }
        }
           
         $fieldset->addField('salesperson_id', 'select', array(
            'label' => Mage::Helper('I95Dev_SalesPerson')->__('Sales Person ID'),
            'class' => 'input-select',
            'required' => true,
            'name' => 'erp_salesperson_code',
            'value' => 'Select Salesperson ID', 
            'values' => $_arrSalesPerson,
        ));
        $this->setForm($form);
        return $this; 
    }
    
    

}