<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author       I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_SalesPerson_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{

    /**
     * Setting the default header and buttons for the Magento To Salesperson Grid
     */
    public function __construct()
    {
        parent::__construct();

        $this->_objectId = 'id';
        $this->_blockGroup = 'salesPerson';
        $this->_controller = 'adminhtml_salesPerson';

        $this->_updateButton('save', 'label', Mage::Helper('I95Dev_SalesPerson')->__('Save Sales Person'));
        $this->_removeButton('delete');
        $this->_addButton('saveandcontinue', array(
            'label' => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick' => 'saveAndContinueEdit()',
            'class' => 'save',
                ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('salesPerson_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'salesPerson_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'salesPerson_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    /**  
     * Setting the default header for Salesperson
     * @return type   
     */
    
    public function getHeaderText()  
    {
        if (Mage::registry('salesPerson_data') && Mage::registry('salesPerson_data')->getId())
        {
            return Mage::Helper('I95Dev_SalesPerson')->__("Edit Sales Person", $this->htmlEscape(Mage::registry('salesPerson_data')->getTitle()));
        }
        else
        {
            return Mage::Helper('I95Dev_SalesPerson')->__('Add Sales Person User');
        }
    }

}