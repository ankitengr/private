<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Assigncsr_Csr extends Mage_Adminhtml_Block_Widget_Form_Container
{

    /**
     * SalesPerson admin assign constructor
     */ 
    public function __construct()
    {
        parent::__construct();


        $this->_objectId = 'id';
        $this->_blockGroup = 'salesPerson';
        $this->_controller = 'adminhtml_assigncsr';
        $this->_updateButton($this->getUrl('*/*/', array('id' => $this->getRequest()->getParam('id'))), 'label', Mage::Helper('I95Dev_SalesPerson')->__('Save Customer'));
        $this->_removeButton('delete');
        $this->_updateButton('back', 'onclick', 'history.go(-1);return false');

        $this->_formScripts[] = "
		 function toggleEditor() {
		 if (tinyMCE.getInstanceById('form_content') == null) {
		 tinyMCE.execCommand('mceAddControl', false, 'edit_form');
		} else {
		tinyMCE.execCommand('mceRemoveControl', false, 'edit_form');
		}
		}
	
		function saveAndContinueEdit(){
		editForm.submit($('edit_form').action+'back/edit/');
		}
		";
    }


    /**
     * get the Header Text
     * @return type 
     */
    public function getHeaderText()
    {
        return Mage::Helper('I95Dev_SalesPerson')->__('Assign Sales Person to Order');
    }

    /**
     * Preapreing Salesperson Layout
     * @return type 
     */
    protected function _prepareLayout()
    {
        if ($this->_blockGroup && $this->_controller && $this->_mode)
        {

            $this->setChild('form', $this->getLayout()->createBlock('salesPerson/adminhtml_assigncsr_csr_form'));
        }

        return parent::_prepareLayout();
    }

}