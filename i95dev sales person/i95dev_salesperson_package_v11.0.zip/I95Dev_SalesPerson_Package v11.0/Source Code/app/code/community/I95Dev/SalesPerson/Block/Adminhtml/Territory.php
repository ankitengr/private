<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Block for display territories Grid
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Territory extends Mage_Adminhtml_Block_Widget_Grid_Container
{

    public function __construct()
    {

        $this->_controller = "adminhtml_territory";
        $this->_blockGroup = "salesPerson";
        $this->_headerText = Mage::helper('I95Dev_SalesPerson')->__("Manage Territories");+
         
        parent::__construct(); 
        $this->_removeButton('add');
      
        
        $this->_addButton('adminhtml_territory', array(
            'label'   => Mage::helper('catalog')->__('Add Territory'),
            'onclick' => "setLocation('{$this->getUrl('*/*/new')}')",
            'class'   => 'add'
        ));
         
            
    }

}