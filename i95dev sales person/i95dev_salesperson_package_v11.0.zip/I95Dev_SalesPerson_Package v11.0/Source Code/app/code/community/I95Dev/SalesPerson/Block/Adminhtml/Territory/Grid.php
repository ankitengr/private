<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Block for display territories Grid
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
class I95Dev_SalesPerson_Block_Adminhtml_Territory_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

    public function __construct()
    {
        parent::__construct();
        $this->setId("territoryGrid");
        $this->setDefaultSort("territory_id");
        $this->setDefaultDir("ASC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel("salesPerson/territory")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn("territory_id", array(
            "header" => Mage::helper('I95Dev_SalesPerson')->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "territory_id",
        ));

        $this->addColumn("territory_name", array(
            "header" => Mage::helper('I95Dev_SalesPerson')->__("Territory Name"),
            "index" => "territory_name",
        ));
        $this->addColumn('territory_desc', array(
            'header' => Mage::helper('I95Dev_SalesPerson')->__('Description'),
            'index' => 'territory_desc',
        ));
        $this->addColumn('territory_country', array(
            'header' => Mage::helper('I95Dev_SalesPerson')->__('Country'),
            'index' => 'territory_country',
        ));
     
        $this->addColumn('action', array(
            'header' => Mage::Helper('I95Dev_SalesPerson')->__('Action'),
            'width' => '100',
            'type' => 'action',
            'getter' => 'getId',
            'actions' => array(
                array(
                    'caption' => Mage::Helper('I95Dev_SalesPerson')->__('Edit'),
                    'url' => array('base' => '*/*/edit'),
                    'field' => 'id'
                )
            ),
            'filter' => false,
            'sortable' => false,
            'index' => 'stores',
            'is_system' => true,
        ));  

        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }
    
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('territory_id');
        $this->getMassactionBlock()->setFormFieldName('territory_id');
        $this->getMassactionBlock()->addItem('delete', array(
        'label'=> Mage::helper('tax')->__('Delete'),
        'url'  => $this->getUrl('*/*/massDelete', array('' => '')),        // public function massDeleteAction() in Mage_Adminhtml_Tax_RateController
        'confirm' => Mage::helper('tax')->__('Are you sure?')
        ));
        
        return $this;
        
    }

}