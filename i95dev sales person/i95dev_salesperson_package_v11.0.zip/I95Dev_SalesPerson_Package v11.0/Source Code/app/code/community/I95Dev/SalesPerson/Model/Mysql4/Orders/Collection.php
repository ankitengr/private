<?php

class I95Dev_SalesPerson_Model_Mysql4_Orders_Collection 
extends Mage_Core_Model_Mysql4_Collection_Abstract
{

    /**
     * Initialize the resource model collection
     */
    public function _construct()
    {
        // parent::_construct(); 
        //$this->_init('salesPerson/orders');
         $this->setModel('adminhtml/report_item');
        $this->_resource = Mage::getResourceModel('salesPerson/orders')->init('salesPerson/orders');
        $this->setConnection($this->getResource()->getReadConnection());
        
        $this->_applyFilters = false;
    }
     
    public function getReportFull($from, $to)
   {
       return $this->_model->getReportFull($this->timeShift($from), $this->timeShift($to));
   }
 
   public function timeShift($datetime)
   {
       return Mage::app()->getLocale()->utcDate(null, $datetime, true, Varien_Date::DATETIME_INTERNAL_FORMAT)->toString(Varien_Date::DATETIME_INTERNAL_FORMAT);
   }
    

    
    

}



?>
