<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Handles sales person creation
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */

/**
 * This class is used for creation of customer
 */
class I95Dev_SalesPerson_Model_SalesPerson_SalesPerson6 extends Mage_Core_Model_Abstract
{

    /**
     *
     * @var SalesPersonEntity
     */
    public $salesperson;
    public $salesPersonId;
    public $customer;

    /**
     *
     * @var array
     */
    protected $exStack = array();

    /**
     * Constructor to load customer and address Entities
     */
    public function __construct()
    {
        $helper = Mage::Helper('I95Dev_SalesPerson');
        $helper->loadClass('SalesPersonEntity');
        $helper->loadClass('OrderSalesPersonEntity');
        $helper->loadClass('CustomerSalesPersonEntity');
        Mage::helper('I95Dev_Base')->loadClass('AddressEntity');
        Mage::helper('I95Dev_Base')->loadClass('CustomerEntity');
    }

    /**
     * To create salesperson
     * @param type $args
     * @return SalesPersonEntity 
     */
    public function CreateUpdateSalesPerson($args = array())
    {
        $helper = Mage::Helper('I95Dev_SalesPerson/salesPerson');
        if (isset($args['salespersonData']['commission']) && $args['salespersonData']['commission'] > 100)
        {
            Mage::getSingleton('adminhtml/session')->addError("Invalid Commission");
            return;
        }
        try
        {
            $salespersonData = $args['salespersonData'];
            $salespersonEntity = new SalesPersonEntity();
            $salespersonEntity->setSalespersonId($salespersonData['username']);
            $salespersonEntity->setSalesTerritoryID($salespersonData['territory_id']);
            $salespersonEntity->setFirstName($salespersonData['firstname']);
            $salespersonEntity->setEmail($salespersonData['email']);
            $salespersonEntity->setCommissionApplyTo($salespersonData['commission_applied_on']);
            $salespersonEntity->setLastName($salespersonData['lastname']);
            if ($salespersonData['is_active'] == 1)
            {
                $salespersonEntity->setInactive(0);
            }
            else
            {
                $salespersonEntity->setInactive(1);
            }
            $salespersonEntity->setPercent($salespersonData['commission']);
            $addressEntity = new AddressEntity();
            $addressEntity->setFirstName($salespersonData['firstname']);

            $addressEntity->setLastName($salespersonData['lastname']);
            $addressEntity->setCity($salespersonData['city']);
            $addressEntity->setAddressLine1($salespersonData['streetaddress1']);
            $addressEntity->setAddressLine2($salespersonData['streetaddress2']);
            $addressEntity->setAddressLine3($salespersonData['streetaddress3']);
            $addressEntity->setAddressLine4($salespersonData['streetaddress4']);
            $addressEntity->setStateCode($salespersonData['state']);
            //$addressEntity->setStateCode($salespersonData['region_name']);
            $addressEntity->setCountryCode($salespersonData['country']);
            $addressEntity->setZip($salespersonData['zip_code']);
            $addressEntity->setPhoneNumber1($salespersonData['phone1']);
            $addressEntity->setPhoneNumber2($salespersonData['phone2']);
            $addressEntity->setPhoneNumber3($salespersonData['phone3']);
            $addressEntity->setFaxNumber($salespersonData['fax']);
            $addressEntityArray[] = $addressEntity;
            $salespersonEntity->setAddressEntity($addressEntityArray);
        }
        catch (Exception $ex)
        {
            
        }
        return $salespersonEntity;
    }

    /**
     * To get salespersonEntity
     * @param array $salesPersonId
     * @return SalespersonEntity
     */
    public function getSalesPersonDataById($salesPersonId)
    {
        $helper = Mage::Helper('I95Dev_SalesPerson/salesPerson');

        try
        {
            $salesPersonObject = $_salesPerson = Mage::getModel('salesPerson/salesPerson')
                    ->load($salesPersonId, 'salesPerson_id');

            $this->salesperson = new SalesPersonEntity();


            $this->salesperson->setSalespersonId($salesPersonObject->getUsername());
            $this->salesperson->setSalesTerritoryID($salesPersonObject->getTerritoryId());
            $this->salesperson->setFirstName($salesPersonObject->getFirstname());
            $this->salesperson->setEmail($salesPersonObject->getEmail());
            $this->salesperson->setCommissionApplyTo($salesPersonObject->getCommissionAppliedOn());
            $this->salesperson->setLastName($salesPersonObject->getLastname());
            if ($salesPersonObject->getStatus() == 1)
            {
                $this->salesperson->setInactive(0);
            }
            else
            {
                $this->salesperson->setInactive(1);
            }
            $this->salesperson->setPercent($salesPersonObject->getCommission());

            $addressEntity = new AddressEntity();
            $addressEntity->setFirstName($salesPersonObject->getFirstname());

            $addressEntity->setLastName($salesPersonObject->getLastname());
            $addressEntity->setCity($salesPersonObject->getCity());
            $addressEntity->setAddressLine1($salesPersonObject->getAddress1());
            $addressEntity->setAddressLine2($salesPersonObject->getAddress2());
            $addressEntity->setAddressLine3($salesPersonObject->getAddress3());
            $addressEntity->setAddressLine4($salesPersonObject->getAddress4());

            $addressEntity->setStateCode($salesPersonObject->getState());
            $addressEntity->setCountryCode($salesPersonObject->getCountry());
            $addressEntity->setZip($salesPersonObject->getZipCode());
            $addressEntity->setPhoneNumber1($salesPersonObject->getPhone1());
            $addressEntity->setPhoneNumber2($salesPersonObject->getPhone2());
            $addressEntity->setPhoneNumber3($salesPersonObject->getPhone3());
            $addressEntity->setFaxNumber($salesPersonObject->getFax());
            $addressEntityArray[] = $addressEntity;
            $this->salesperson->setAddressEntity($addressEntityArray);
        }
        catch (Exception $ex)
        {
            
        }
        return $this->salesperson;
    }

    /**
     * get stack
     * @return array
     */
    public function getStack()
    {
        return $this->exStack;
    }

}