<?php

class I95Dev_SalesPerson_Model_Mysql4_Report_Report_Collection 
extends  Mage_Core_Model_Mysql4_Collection_Abstract //Mage_Reports_Model_Mysql4_Report_Collection  
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('salesPerson/salesPerson');
    }
    
     
 
    protected function _joinFields($from = '', $to = '')
    {
         $this->addFieldToFilter('created_at' , array("from" => $from, "to" => $to));
         $this->addFieldToSelect('*');
         $this->getSelect()->group('username');
          $this->getSelect()->columns(array('value' => 'count(username)'));
 
        return $this;
    }
 
    public function setDateRange($from, $to)
    {
        $this->_reset();
        $this->_joinFields($this->timeShift($from), $this->timeShift($to));
        return $this;
    }
 
    public function load($printQuery = false, $logQuery = false)
    {
        if ($this->isLoaded()) {
            return $this;
        }
        parent::load($printQuery, $logQuery);
        return $this;
    }
 
    public function setStoreIds($storeIds)
    {
        return $this;
    }
    
    public function timeShift($datetime)
   {
       return Mage::app()->getLocale()->utcDate(null, $datetime, true, Varien_Date::DATETIME_INTERNAL_FORMAT)->toString(Varien_Date::DATETIME_INTERNAL_FORMAT);
   }
    

    
}
  
?>
