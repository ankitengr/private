<?php

/**
 * i95Dev.com
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://store.i95dev.com/LICENSE-M1.txt
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@i95dev.com so we can send you a copy immediately.
 *
 *
 * @category       I95Dev
 * @package        I95Dev_SalesPerson
 * @Description    Adminhtml Customer grid block to display target customer id
 * @author         I95Dev
 * @copyright      Copyright (c) 2013 i95Dev
 * @license        http://store.i95dev.com/LICENSE-M1.txt
 */
$installer = $this;

$installer->startSetup();

$installer->run("
		 DROP TABLE IF EXISTS {$this->getTable('i95dev_sales_person')};
		CREATE TABLE {$this->getTable('i95dev_sales_person')} (
			`salesPerson_id` int(11) unsigned NOT NULL auto_increment, 
			`username` VARCHAR(255) NOT NULL,
			`firstname` VARCHAR(255) NOT NULL,
			`lastname` VARCHAR(255) NOT NULL,
			`email` VARCHAR(255) NOT NULL,
                        `commission` float(5) DEFAULT NULL,
			`total_commission` float(10) DEFAULT NULL,
			`commission_applied_on` VARCHAR(255) DEFAULT NULL,
			`magento_id` INT(10) NOT NULL,
			`status` int(1) NOT NULL DEFAULT '1',
			`code` VARCHAR(255) NOT NULL,
			`key` TEXT NOT NULL,
			`territory_id` VARCHAR(255) NOT NULL,
			`middlename` VARCHAR(255) NOT NULL,
			`address1`  VARCHAR(500) not null default '',
			`address2` VARCHAR(500) not null default '',
			`address3` VARCHAR(500) not null default '',
			`address4` VARCHAR(500) not null default '',
			`zip_code` varchar(100) default NULL,
			`city` varchar(100) default NULL,
			`state` varchar(100) default NULL,
			`country` varchar(100) default NULL,
			`phone1` varchar(100) default NULL,
			`phone2` varchar(100) default NULL,
			`phone3` varchar(100) default NULL,
			`fax` varchar(100) default NULL,
                        `created_at` datetime default NULL,
                        `updated_at` varchar(100) default NULL,
		PRIMARY KEY (`salesPerson_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		");



$configValuesMap = array(
    'salesperson/salesPerson_email/template' => 'salesperson/salesPerson_email/template',
);

foreach ($configValuesMap as $configPath => $configValue)
{
    $installer->setConfigData($configPath, $configValue);
}
$installer->endSetup();